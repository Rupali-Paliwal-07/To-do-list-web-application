from tokenize import Special
import pyttsx3
import subprocess

import speech_recognition as sr
import datetime
import webbrowser
import os
import smtplib
import ctypes
import time
import requests
import shutil

engine = pyttsx3.init('sapi5')

voices = engine.getProperty('voices')
engine.setProperty("rate", 178)
print("please choose your assistant : 1-blaze 2-MJ")
voice_type=int(input())

def speak(audio):
	engine.say(audio)
	engine.runAndWait()

if voice_type==1:

	engine.setProperty('voice', voices[0].id)
	assisname =("blaze 1 point o")
	speak("I am your assistant")
	speak(assisname)
else:
   engine.setProperty('voice', voices[1].id)
   assisname =("MJ 2 point o")
   speak("I am your Assistant")
   speak(assisname)


def takeCommand():
	
	r = sr.Recognizer()
	
	with sr.Microphone() as source:
		
		print("Listening...")
		r.pause_threshold = 0.5
		audio = r.listen(source)

	try:
		print("Recognizing...")
		query = r.recognize_google(audio, language ='en-in')
		print(f"User said: {query}\n")

	except Exception as e:
		print(e)
		print("Unable to Recognize your voice.")
		return "None"
	
	return query
	    


def wishMe():
	hour = int(datetime.datetime.now().hour)
	if hour>= 0 and hour<12:
		speak("Good Morning Sir !")

	elif hour>= 12 and hour<18:
		speak("Good Afternoon Sir !")

	else:
		speak("Good Evening Sir !")

def tellTime():

    time = str(datetime.datetime.now())
  
    print(time)
    hour = time[11:13]
    min = time[14:16]
    speak( "The time is sir" + hour + "Hours and" + min + "Minutes")    

def tellDay():
      
    # This function is for telling the
    # day of the week
    day = datetime.datetime.today().weekday() + 1
      
    #this line tells us about the number 
    # that will help us in telling the day
    Day_dict = {1: 'Monday', 2: 'Tuesday', 
                3: 'Wednesday', 4: 'Thursday', 
                5: 'Friday', 6: 'Saturday',
                7: 'Sunday'}
      
    if day in Day_dict.keys():
        day_of_the_week = Day_dict[day]
        print(day_of_the_week)
        speak("The day is " + day_of_the_week)
  
  



def stop():
			speak("for how much time you want to stop jarvis from listening commands")
			a = int(takeCommand())
			time.sleep(a)
			print(a)
'''def sendEmail(to, content):
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.ehlo()
	server.starttls()
	
	# Enable low security in gmail
	server.login('your email id', 'your email password')
	server.sendmail('your email id', to, content)
	server.close()'''



if __name__ == "__main__":

    
	clear = lambda: os.system('cls')
	clear()

	wishMe()
	'''speak("What should i call you sir")
	uname = takeCommand()
	speak("Welcome Mister")
	speak(uname)
	columns = shutil.get_terminal_size().columns
	speak("How can i Help you, Sir")  '''

	tellDay()
	tellTime()

	
	while True:

		speak(' hello sir, whats gonna be your todays plan')
		query = takeCommand().lower()

		if 'add task' in query:
			speak("What should be in the title, sir")
			note = takeCommand()
			# file = open('jarvis.txt', 'w')
			speak("Does it include any description?")
			snfm = takeCommand()
			if 'yes' in snfm :
				desc = takeCommand()
			#return (note,desc)
				speak(note,desc)
				print(note,desc)


			
			

		elif 'delete task' in query:
			speak("which task you wanted to sir\n")
			delt = takeCommand()
			if delt in note:
				del(delt)



        
		elif 'search' in query:	
			speak("which task you wanted to search sir\n")
			seach = takeCommand()
			if seach in note:
				speak(seach)
				print(seach)

				#return(seach)
			#query = query.replace("search", "")

		#elif 'wait a min' or 'let me think ' or 'hang on'or 'dont listen' in query:
		#	stop()



		
		elif 'exit' in query:
			speak("Thanks for giving me your time")
			exit()
		
			
		#elif "logout" or "log off" or "sleep" or "exit" in query:
		#	speak("Thanks for giving me your time the system is Hibernating")
		#	subprocess.call("logout / h")

		elif "stat" in query:
			speak("sir current progress is ")
			#plt.show()

		elif 'how are you' in query:
			speak("I am fine, Thank you")
			speak("How are you, Sir")
			if "ok " or "fine"or"good":
				speak("glad to hear you that sir")


		elif "change my name" in query:
			speak("what should i call you  Sir ")
			uname = takeCommand()
			speak("ok i will call you")
			speak(uname)

		elif "what's your name" in query or "What is your name" in query:
			speak("My friends call me")
			speak(assisname)
			print("My friends call me", assisname)

		elif "who made you" in query or "who created you" in query:
			speak("I have been created by shivaay.")

		elif "why you came to world" in query:
			speak("i'm here to manage your day to day goals and make your day more productive")

		elif "who are you" in query:
			speak("I am your virtual assistant to manage your daily to do list")
				
		elif "blaze" in query:
			
			wishMe()
			speak("i'm blaze 1 point o in your service ")
			speak(uname)

		elif "Good Morning" in query:
			speak("A warm" +query)
			speak("How are you ")
			speak(uname)
		elif "MJ" in query:
			wishMe()
			speak("i'm MJ 2 point o in your service ")
			speak(uname)    



		'''elif "what is" in query or "who is" in query:
			
			# Use the same API key
			# that we have generated earlier
			client = wolframalpha.Client("API_ID")
			res = client.query(query)
			
			try:
				print (next(res.results).text)
				speak (next(res.results).text)
			except StopIteration:
				print ("No results")'''



