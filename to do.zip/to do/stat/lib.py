# importing libraries
import matplotlib.pyplot as plt
import seaborn as sns

# declaring data
data = [44, 45]
keys = ['Class 1', 'Class 2']

# define Seaborn color palette to use
palette_color = sns.color_palette('bright')

# plotting data on chart
plt.pie(data, labels=keys, colors=palette_color, autopct='%.0f%%')

# displaying chart
plt.show()
